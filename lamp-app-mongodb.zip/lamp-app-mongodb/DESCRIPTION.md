## Cloudron LAMP Stack

LAMP is an archetypal model of web service stacks, named as an acronym of the names of its original four open-source components: the Linux operating system,
the Apache HTTP Server, the MySQL relational database management system (RDBMS), and the PHP programming language.

## ionCube

ionCube is a PHP module extension that loads encrypted PHP files and speeds up webpages. ionCube is pre-installed
and enabled by default.

### Remote Terminal

Use the [web terminal](https://docs.cloudron.io/apps/#web-terminal) for a remote shell connection into the
app to adjust configuration files like `php.ini`.

